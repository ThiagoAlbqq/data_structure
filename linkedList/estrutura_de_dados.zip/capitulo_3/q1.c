#include <stdio.h>
void main()
{
    printf("Quando potencia = 0, a função f(2) é executada, realizando operações de comparação (>= e ==).\n"
           "Quando potencia = 1, a função f(3) é chamada, envolvendo operações de comparação (>=, ==, <).\n"
           "Para valores de potencia > 1, a função f(n) é definida como n + 2.");
}